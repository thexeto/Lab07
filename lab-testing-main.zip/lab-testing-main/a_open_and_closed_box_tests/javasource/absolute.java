// Code for White-box test exercise
public static int absoluteValueOf (int x) {
  if (x < -1)
     return -x;
  else
     return x;
}
