export PYTHONPATH=".:$PYTHONPATH"
pytest -x -rx tests
