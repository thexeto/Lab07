export PYTHONPATH=".:$PYTHONPATH"
pytest -x tests
