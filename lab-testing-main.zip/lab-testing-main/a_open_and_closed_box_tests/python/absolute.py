# translated from java by ChatGPT
def absolute_value_of(x):
    if x < -1:
        return -x
    else:
        return x
